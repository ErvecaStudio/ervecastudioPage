using DG.Tweening;
using DG.Tweening.Core;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Erveca.CollectATon
{
    public class CameraPivotRotator : MonoBehaviour
    {
        [SerializeField] private float duration = 0.5f;
        [SerializeField] private Ease ease = Ease.InOutSine;

        [Header("Inputs")]
        [SerializeField] private Key leftKey = Key.A;
        [SerializeField] private Key rightKey = Key.D;

        private int step;
        private float yaw;
        private Tween tween;
        private DOGetter<float> getYaw;
        private DOSetter<float> setYaw;

        private const float StepAngle = 90f;

        private void Awake()
        {
            getYaw = () => yaw;
            setYaw = value =>
            {
                yaw = value;
                transform.localRotation = Quaternion.Euler(0f, yaw, 0f);
            };
        }

        private void OnDestroy() => tween?.Kill();

        private void Update()
        {
            Keyboard keyboard = Keyboard.current;

            if (keyboard != null)
            {
                if (keyboard[leftKey].wasPressedThisFrame)
                {
                    RotateLeft();
                }

                if (keyboard[rightKey].wasPressedThisFrame)
                {
                    RotateRight();
                }
            }
        }

        public void RotateRight() => Rotate(1);

        public void RotateLeft() => Rotate(-1);

        public void Restart()
        {
            tween?.Kill();
            step = 0;
            yaw = 0f;
            transform.localRotation = Quaternion.identity;
        }

        private void Rotate(int direction)
        {
            step += direction;
            tween?.Kill();
            tween = DOTween.To(getYaw, setYaw, step * StepAngle, duration).SetEase(ease);
        }
    }
}