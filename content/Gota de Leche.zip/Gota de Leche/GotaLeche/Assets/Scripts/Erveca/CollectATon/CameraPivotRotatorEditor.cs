#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

namespace Erveca.CollectATon
{
    [CustomEditor(typeof(CameraPivotRotator))]
    public class CameraPivotRotatorEditor : Editor
    {
        public override void OnInspectorGUI()
        {
            DrawDefaultInspector();
            EditorGUILayout.Space();

            CameraPivotRotator rotator = (CameraPivotRotator)target;

            using (new EditorGUI.DisabledScope(!Application.isPlaying))
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    if (GUILayout.Button("Rotate Left"))
                    {
                        rotator.RotateLeft();
                    }

                    if (GUILayout.Button("Rotate Right"))
                    {
                        rotator.RotateRight();
                    }
                }

                if (GUILayout.Button("Restart"))
                {
                    rotator.Restart();
                }
            }
        }
    }
}
#endif