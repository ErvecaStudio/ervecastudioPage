using System;
using DG.Tweening;
using UnityEngine;

namespace Erveca.CollectATon
{
    [Serializable]
    public class CrystalBobAnimation : ICrystalAnimation
    {
        [SerializeField] private float height = 0.5f;
        [SerializeField] private float duration = 1.2f;
        [SerializeField] private Ease ease = Ease.InOutSine;

        private Transform target;
        private Vector3 basePosition;
        private Tween tween;

        public bool IsPlaying => tween != null && tween.IsActive();

        public void Bake(Transform target)
        {
            this.target = target;
            basePosition = target.localPosition;
        }

        public void Play()
        {
            if (!IsPlaying && target != null)
            {
                target.localPosition = basePosition;
                tween = target
                    .DOLocalMoveY(basePosition.y + height, duration)
                    .SetEase(ease)
                    .SetLoops(-1, LoopType.Yoyo);
            }
        }

        public void Stop()
        {
            tween?.Kill();
            tween = null;
        }
    }
}
