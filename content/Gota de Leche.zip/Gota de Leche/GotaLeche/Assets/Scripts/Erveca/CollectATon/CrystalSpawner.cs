using System;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;

namespace Erveca.CollectATon
{
    public enum CrystalSpawnerState
    {
        Inactive,
        Active
    }

    public class CrystalSpawner : MonoBehaviour
    {
        [SerializeField] private Transform crystal;
        [SerializeField] private float scaleDuration = 0.4f;
        [SerializeField] private Ease scaleEase = Ease.OutQuad;
        [SerializeReference] private ICrystalAnimation[] animations = Array.Empty<ICrystalAnimation>();

        public bool IsActive => state == CrystalSpawnerState.Active;
        public CrystalSpawnerState State => state;
        public IReadOnlyList<ICrystalAnimation> Animations => animations;
        public Transform Crystal => crystal;

        private CrystalSpawnerState state;
        private Vector3 activeScale;
        private Tween scaleTween;
        private TweenCallback stopCallback;

        private void Awake()
        {
            state = CrystalSpawnerState.Inactive;
            stopCallback = StopAnimations;

            if (crystal == null && transform.childCount > 0)
            {
                crystal = transform.GetChild(0);
            }

            if (crystal != null)
            {
                crystal.SetLocalPositionAndRotation(new(0f, 1f, 0f), Quaternion.identity);
                activeScale = crystal.localScale;
                crystal.localScale = Vector3.zero;

                for (int i = 0; i < animations.Length; i++)
                {
                    if (animations[i] != null)
                    {
                        animations[i].Bake(crystal);
                    }
                }
            }
        }

        private void OnDestroy()
        {
            scaleTween?.Kill();
            StopAnimations();
        }

        public void SetActive(bool value)
        {
            if (value)
            {
                Activate();
                return;
            }
            Deactivate();
        }

        public void Activate()
        {
            if (state != CrystalSpawnerState.Active && crystal != null)
            {
                state = CrystalSpawnerState.Active;
                PlayAnimations();
                TweenScale(activeScale, null);
            }
        }

        public void Deactivate()
        {
            if (state != CrystalSpawnerState.Inactive && crystal != null)
            {
                state = CrystalSpawnerState.Inactive;
                TweenScale(Vector3.zero, stopCallback);
            }
        }

        private void TweenScale(Vector3 target, TweenCallback onComplete)
        {
            scaleTween?.Kill();
            scaleTween = crystal.DOScale(target, scaleDuration).SetEase(scaleEase);

            if (onComplete != null)
            {
                scaleTween.OnComplete(onComplete);
            }
        }

        private void PlayAnimations()
        {
            for (int i = 0; i < animations.Length; i++)
            {
                if (animations[i] != null)
                {
                    animations[i].Play();
                }
            }
        }

        private void StopAnimations()
        {
            for (int i = 0; i < animations.Length; i++)
            {
                if (animations[i] != null)
                {
                    animations[i].Stop();
                }
            }
        }

#if UNITY_EDITOR
        private void OnValidate()
        {
            if (animations != null)
            {
                HashSet<Type> seen = new HashSet<Type>();
                List<ICrystalAnimation> result = new List<ICrystalAnimation>(animations.Length);
                bool changed = false;

                for (int i = 0; i < animations.Length; i++)
                {
                    if (animations[i] != null && seen.Add(animations[i].GetType()))
                    {
                        result.Add(animations[i]);
                        continue;
                    }
                    changed = true;
                }

                if (changed)
                {
                    animations = result.ToArray();
                }
            }
        }
#endif
    }
}
