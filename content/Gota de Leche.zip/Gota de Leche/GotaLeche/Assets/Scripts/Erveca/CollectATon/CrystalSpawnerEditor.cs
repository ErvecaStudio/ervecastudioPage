#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace Erveca.CollectATon
{
    [CustomEditor(typeof(CrystalSpawner))]
    public class CrystalSpawnerEditor : Editor
    {
        private SerializedProperty animations;

        private void OnEnable() => animations = serializedObject.FindProperty("animations");

        public override bool RequiresConstantRepaint() => Application.isPlaying;

        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            DrawPropertiesExcluding(serializedObject, "m_Script", "animations");
            DrawAnimations();
            serializedObject.ApplyModifiedProperties();
            DrawRuntime();
        }

        private void DrawAnimations()
        {
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Animations", EditorStyles.boldLabel);

            int removeIndex = -1;

            for (int i = 0; i < animations.arraySize; i++)
            {
                SerializedProperty element = animations.GetArrayElementAtIndex(i);

                using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
                {
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        EditorGUILayout.LabelField(GetName(element.managedReferenceValue), EditorStyles.boldLabel);

                        if (GUILayout.Button("X", GUILayout.Width(22f)))
                        {
                            removeIndex = i;
                        }
                    }

                    SerializedProperty child = element.Copy();
                    SerializedProperty end = element.GetEndProperty();
                    bool enter = child.NextVisible(true);

                    while (enter && !SerializedProperty.EqualContents(child, end))
                    {
                        EditorGUILayout.PropertyField(child, true);
                        enter = child.NextVisible(false);
                    }
                }
            }

            if (removeIndex >= 0)
            {
                animations.DeleteArrayElementAtIndex(removeIndex);
            }

            if (GUILayout.Button("Add Animation"))
            {
                ShowAddMenu();
            }
        }

        private void ShowAddMenu()
        {
            HashSet<Type> existing = new();

            for (int i = 0; i < animations.arraySize; i++)
            {
                object value = animations.GetArrayElementAtIndex(i).managedReferenceValue;

                if (value != null)
                {
                    existing.Add(value.GetType());
                }
            }

            GenericMenu menu = new ();

            foreach (Type type in TypeCache.GetTypesDerivedFrom<ICrystalAnimation>())
            {
                if (!type.IsAbstract && !type.IsInterface)
                {
                    GUIContent label = new (GetName(type));

                    if (existing.Contains(type))
                    {
                        menu.AddDisabledItem(label);
                    }
                    else
                    {
                        Type captured = type;
                        menu.AddItem(label, false, () => AddAnimation(captured));
                    }
                }
            }

            menu.ShowAsContext();
        }

        private void AddAnimation(Type type)
        {
            serializedObject.Update();
            int index = animations.arraySize;
            animations.arraySize++;
            animations.GetArrayElementAtIndex(index).managedReferenceValue = Activator.CreateInstance(type);
            serializedObject.ApplyModifiedProperties();
        }

        private void DrawRuntime()
        {
            CrystalSpawner spawner = (CrystalSpawner)target;

            EditorGUILayout.Space();

            using (new EditorGUI.DisabledScope(!Application.isPlaying))
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    if (GUILayout.Button("Activate"))
                    {
                        spawner.Activate();
                    }

                    if (GUILayout.Button("Deactivate"))
                    {
                        spawner.Deactivate();
                    }
                }
            }

            if (Application.isPlaying)
            {
                EditorGUILayout.LabelField("State", spawner.State.ToString());
                EditorGUILayout.LabelField("Active animations", EditorStyles.boldLabel);

                int playing = 0;
                IReadOnlyList<ICrystalAnimation> list = spawner.Animations;

                for (int i = 0; i < list.Count; i++)
                {
                    if (list[i] != null && list[i].IsPlaying)
                    {
                        EditorGUILayout.LabelField(GetName(list[i]));
                        playing++;
                    }
                }

                if (playing == 0)
                {
                    EditorGUILayout.LabelField("None");
                }
            }
        }

        private static string GetName(object value) => value != null ? GetName(value.GetType()) : "Missing";

        private static string GetName(Type type) => ObjectNames.NicifyVariableName(type.Name);
    }
}
#endif
