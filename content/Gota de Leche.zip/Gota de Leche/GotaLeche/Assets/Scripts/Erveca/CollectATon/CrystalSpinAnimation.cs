using System;
using DG.Tweening;
using UnityEngine;

namespace Erveca.CollectATon
{
    [Serializable]
    public class CrystalSpinAnimation : ICrystalAnimation
    {
        [SerializeField] private float secondsPerTurn = 4f;

        private Transform target;
        private Tween tween;

        public bool IsPlaying => tween != null && tween.IsActive();

        public void Bake(Transform target)
        {
            this.target = target;
        }

        public void Play()
        {
            if (!IsPlaying && target != null)
            {
                tween = target
                    .DOLocalRotate(new Vector3(0f, 360f, 0f), secondsPerTurn, RotateMode.LocalAxisAdd)
                    .SetEase(Ease.Linear)
                    .SetLoops(-1, LoopType.Incremental);
            }
        }

        public void Stop()
        {
            tween?.Kill();
            tween = null;
        }
    }
}
