using UnityEngine;

namespace Erveca.CollectATon
{
    public interface ICrystalAnimation
    {
        bool IsPlaying { get; }
        void Bake(Transform target);
        void Play();
        void Stop();
    }
}
