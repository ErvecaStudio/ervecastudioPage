using DG.Tweening;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Erveca.CollectATon
{
    [RequireComponent(typeof(Image))]
    public class ImageAlphaButton : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, IPointerDownHandler, IPointerUpHandler, IPointerClickHandler
    {
        [SerializeField] private float hoverAlpha = 0.8f;
        [SerializeField] private float pressedAlpha = 0.7f;
        [SerializeField] private float duration = 0.1f;
        [SerializeField] private Ease ease = Ease.OutQuad;
        [SerializeField] private UnityEvent onClick;

        private Image image;
        private float idleAlpha;
        private bool hovered;
        private bool pressed;
        private Tween tween;

        private void Awake()
        {
            image = GetComponent<Image>();
            idleAlpha = image.color.a;
        }

        private void OnDisable()
        {
            tween?.Kill();
            hovered = false;
            pressed = false;
            Color color = image.color;
            color.a = idleAlpha;
            image.color = color;
        }

        public void OnPointerEnter(PointerEventData eventData)
        {
            hovered = true;
            Refresh();
        }

        public void OnPointerExit(PointerEventData eventData)
        {
            hovered = false;
            pressed = false;
            Refresh();
        }

        public void OnPointerDown(PointerEventData eventData)
        {
            pressed = true;
            Refresh();
        }

        public void OnPointerUp(PointerEventData eventData)
        {
            pressed = false;
            Refresh();
        }

        public void OnPointerClick(PointerEventData eventData)
        {
            if (eventData.button == PointerEventData.InputButton.Left)
            {
                onClick.Invoke();
            }
        }

        private void Refresh()
        {
            float target = pressed ? pressedAlpha : hovered ? hoverAlpha : idleAlpha;
            tween?.Kill();
            tween = image.DOFade(target, duration).SetEase(ease);
        }
    }
}