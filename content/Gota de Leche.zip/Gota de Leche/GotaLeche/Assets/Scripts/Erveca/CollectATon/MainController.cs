using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.InputSystem;
using UnityRandom = UnityEngine.Random;

namespace Erveca.CollectATon
{
    public class MainController : MonoBehaviour
    {
        [SerializeField] private Transform spawnersRoot;
        [SerializeField] private Camera cam;
        [SerializeField] private float maxRayDistance = 100f;

        [Header("Game")]
        [SerializeField] private int goalPoints = 20;
        [SerializeField] private float startTime = 30f;

        [Header("Difficulty")]
        [Tooltip("X: progress (points / goal), Y: difficulty 0 = easy, 1 = hard")]
        [SerializeField] private AnimationCurve difficultyCurve = AnimationCurve.Linear(0f, 0f, 1f, 1f);

        [Header("Easy (difficulty 0) - x = min, y = max")]
        [SerializeField] private Vector2 spawnDelayEasy = new Vector2(1.5f, 3f);
        [SerializeField] private Vector2 timeBonusEasy = new Vector2(2f, 3f);
        [SerializeField] private int activeCountEasy = 1;

        [Header("Hard (difficulty 1) - x = min, y = max")]
        [SerializeField] private Vector2 spawnDelayHard = new Vector2(0.4f, 1f);
        [SerializeField] private Vector2 timeBonusHard = new Vector2(0.8f, 1.2f);
        [SerializeField] private int activeCountHard = 4;

        [Header("Events")]
        [SerializeField] private UnityEvent onWin;
        [SerializeField] private UnityEvent onLose;
        [SerializeField] private UnityEvent<int> onSecondsChanged;
        [SerializeField] private UnityEvent<int> onPointsChanged;

        public int Points => points;
        public int GoalPoints => goalPoints;
        public bool IsRunning => state != null;

        private int crystalMask;
        private int points;
        private int shownSeconds;
        private float timeLeft;
        private float spawnTimer;
        private Action state;

        private readonly Dictionary<GameObject, CrystalSpawner> crystals = new();
        private readonly List<CrystalSpawner> spawners = new();

        private void Start()
        {
            if (cam == null)
            {
                cam = Camera.main;
            }

            crystalMask = LayerMask.GetMask("Crystal");

            CrystalSpawner[] found = spawnersRoot.GetComponentsInChildren<CrystalSpawner>(true);

            for (int i = 0; i < found.Length; i++)
            {
                Transform crystal = found[i].Crystal;

                if (crystal != null)
                {
                    crystals[crystal.gameObject] = found[i];
                    spawners.Add(found[i]);
                }
            }

            Restart();
        }

        private void Update() => state?.Invoke();

        public void Restart()
        {
            DeactivateAll();
            points = 0;
            timeLeft = startTime;
            shownSeconds = -1;
            spawnTimer = RandomSpawnDelay(Difficulty());
            state = Playing;
            onPointsChanged.Invoke(points);
            NotifySeconds();
        }

        public void TryCollect(Vector2 screenPosition)
        {
            if (IsRunning && Physics.Raycast(cam.ScreenPointToRay(screenPosition), out RaycastHit hit, maxRayDistance, crystalMask))
            {
                if (crystals.TryGetValue(hit.collider.gameObject, out CrystalSpawner spawner) && spawner.IsActive)
                {
                    spawner.Deactivate();
                    Collect();
                }
            }
        }

        private void Collect()
        {
            float difficulty = Difficulty();
            points++;
            timeLeft += UnityRandom.Range(Mathf.Lerp(timeBonusEasy.x, timeBonusHard.x, difficulty), Mathf.Lerp(timeBonusEasy.y, timeBonusHard.y, difficulty));
            onPointsChanged.Invoke(points);
            NotifySeconds();
        }

        private void TickSpawn(float dt)
        {
            float difficulty = Difficulty();
            int target = Mathf.Min(Mathf.Max(1, Mathf.RoundToInt(Mathf.Lerp(activeCountEasy, activeCountHard, difficulty))), spawners.Count);
            int active = CountActive();

            if (active < target)
            {
                spawnTimer -= dt;

                if (spawnTimer <= 0f)
                {
                    ActivateRandomInactive(spawners.Count - active);
                    spawnTimer = RandomSpawnDelay(difficulty);
                }
            }
        }

        private void ActivateRandomInactive(int inactiveCount)
        {
            int pick = UnityRandom.Range(0, inactiveCount);

            for (int i = 0; i < spawners.Count; i++)
            {
                if (!spawners[i].IsActive)
                {
                    if (pick == 0)
                    {
                        spawners[i].Activate();
                        break;
                    }

                    pick--;
                }
            }
        }

        private int CountActive()
        {
            int count = 0;

            for (int i = 0; i < spawners.Count; i++)
            {
                if (spawners[i].IsActive)
                {
                    count++;
                }
            }

            return count;
        }

        private void DeactivateAll()
        {
            for (int i = 0; i < spawners.Count; i++)
            {
                spawners[i].Deactivate();
            }
        }

        private float Difficulty()
        {
            float progress = Mathf.Clamp01((float)points / Mathf.Max(1, goalPoints));
            return Mathf.Clamp01(difficultyCurve.Evaluate(progress));
        }

        private float RandomSpawnDelay(float difficulty) => UnityRandom.Range(Mathf.Lerp(spawnDelayEasy.x, spawnDelayHard.x, difficulty), Mathf.Lerp(spawnDelayEasy.y, spawnDelayHard.y, difficulty));

        private void NotifySeconds()
        {
            int seconds = Mathf.CeilToInt(timeLeft);

            if (seconds != shownSeconds)
            {
                shownSeconds = seconds;
                onSecondsChanged.Invoke(seconds);
            }
        }

        private void Playing()
        {
            float dt = Time.deltaTime;
            Pointer pointer = Pointer.current;

            if (pointer != null && pointer.press.wasPressedThisFrame)
            {
                TryCollect(pointer.position.ReadValue());
            }

            timeLeft -= dt;
            NotifySeconds();
            TickSpawn(dt);
            EvaluateEnd();
        }

        private void EvaluateEnd()
        {
            if (points >= goalPoints)
            {
                Finish(true);
            }
            else if (timeLeft <= 0f)
            {
                Finish(false);
            }
        }

        private void Finish(bool won)
        {
            state = null;
            DeactivateAll();

            if (won)
            {
                onWin.Invoke();
                return;
            }
            onLose.Invoke();
        }
    }
}