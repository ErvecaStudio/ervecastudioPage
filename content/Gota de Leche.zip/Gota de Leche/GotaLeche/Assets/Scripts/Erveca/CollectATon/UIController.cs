using DG.Tweening;
using TMPro;
using UnityEngine;

namespace Erveca.CollectATon
{
    public class UIController : MonoBehaviour
    {
        [Header("HUD")]
        [SerializeField] private TMP_Text timeText;
        [SerializeField] private TMP_Text pointsText;
        [SerializeField] private bool hideHudOnEnd = true;

        [Header("End game")]
        [SerializeField] private CanvasGroup endGamePanel;
        [SerializeField] private TMP_Text endTitleText;
        [SerializeField] private TMP_Text endMessageText;
        [SerializeField] private TMP_Text bestScoreText;

        [Header("Messages")]
        [SerializeField] private string pointMessage = "Puntos: ";
        [SerializeField] private string winTitle = "¡Victoria!";
        [SerializeField] private string loseTitle = "Derrota";
        [SerializeField] private string winMessage = "Has conseguido todos los puntos";
        [SerializeField] private string loseMessage = "Se ha acabado el tiempo";
        [SerializeField] private string bestScoreMessage = "Record: ";

        [Header("Animations")]
        [SerializeField] private float punchScale = 1.3f;
        [SerializeField] private float pointsDuration = 0.25f;
        [SerializeField] private Ease pointsEase = Ease.OutBack;
        [SerializeField] private float secondsDuration = 0.25f;
        [SerializeField] private Ease secondsEase = Ease.OutBack;
        [SerializeField] private float panelDuration = 0.4f;
        [SerializeField] private Ease panelEase = Ease.OutQuad;

        private Vector3 pointsBaseScale;
        private Vector3 timeBaseScale;
        private Tween pointsTween;
        private Tween secondsTween;
        private Tween panelTween;
        private int lastSeconds;
        private int currentPoints;

        private const string BestScoreKey = "CollectATon.BestScore";

        private void Awake()
        {
            if(pointsText && timeText && endGamePanel) 
            { 
                pointsBaseScale = pointsText.rectTransform.localScale;
                timeBaseScale = timeText.rectTransform.localScale;
                lastSeconds = -1;
                endGamePanel.alpha = 0f;
                endGamePanel.interactable = false;
                endGamePanel.blocksRaycasts = false;
                return;
            }
            enabled = false;
            gameObject.SetActive(false);
        }

        private void OnDestroy()
        {
            pointsTween?.Kill();
            secondsTween?.Kill();
            panelTween?.Kill();
        }

        public void SetPoints(int points)
        {
            pointsText.text = pointMessage + points;

            if (points > 0)
            {
                pointsTween = Punch(pointsTween, pointsText.rectTransform, pointsBaseScale, pointsDuration, pointsEase);
            }
        }

        public void SetSeconds(int seconds)
        {
            timeText.SetText("{0}", seconds);

            if (lastSeconds >= 0 && seconds > lastSeconds)
            {
                secondsTween = Punch(secondsTween, timeText.rectTransform, timeBaseScale, secondsDuration, secondsEase);
            }

            lastSeconds = seconds;
        }

        public void ShowWin()
        {
            SaveBestScore();
            ShowEnd(winTitle, winMessage);
        }

        public void ShowLose()
        {
            SaveBestScore();
            ShowEnd(loseTitle, loseMessage);
        }

        public void Restart()
        {
            currentPoints = 0;
            lastSeconds = -1;
            HideEndPanel();
        }

        public void HideEndPanel()
        {
            ShowHUD(true);
            panelTween?.Kill();
            endGamePanel.interactable = false;
            endGamePanel.blocksRaycasts = false;
            panelTween = endGamePanel.DOFade(0f, panelDuration).SetEase(panelEase);
        }

        private void SaveBestScore()
        {
            int score = currentPoints + Mathf.Max(0, lastSeconds);

            if (!PlayerPrefs.HasKey(BestScoreKey) || score > PlayerPrefs.GetInt(BestScoreKey))
            {
                PlayerPrefs.SetInt(BestScoreKey, score);
                PlayerPrefs.Save();
            }
        }

        public void PreviewEnd(bool win) => ShowEnd(win ? winTitle : loseTitle, win ? winMessage : loseMessage);

        private void ShowEnd(string title, string message)
        {
            ShowHUD(!hideHudOnEnd);
            endTitleText.text = title;
            endMessageText.text = message;
            bestScoreText.text = PlayerPrefs.HasKey(BestScoreKey)
                ? bestScoreMessage + PlayerPrefs.GetInt(BestScoreKey)
                : string.Empty;

            panelTween?.Kill();
            endGamePanel.interactable = true;
            endGamePanel.blocksRaycasts = true;
            panelTween = endGamePanel.DOFade(1f, panelDuration).SetEase(panelEase);
        }

        private void ShowHUD(bool value) 
        {
            timeText.gameObject.SetActive(value);
            pointsText.gameObject.SetActive(value);
        }

        private Tween Punch(Tween previous, Transform target, Vector3 baseScale, float duration, Ease ease)
        {
            previous?.Kill();
            target.localScale = baseScale * punchScale;
            return target.DOScale(baseScale, duration).SetEase(ease);
        }
    }
}