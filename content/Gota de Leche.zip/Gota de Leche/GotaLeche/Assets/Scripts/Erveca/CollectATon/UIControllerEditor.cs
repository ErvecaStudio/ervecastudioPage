using UnityEditor;
using UnityEngine;

namespace Erveca.CollectATon
{
    [CustomEditor(typeof(UIController))]
    public class UIControllerEditor : Editor
    {
        public override void OnInspectorGUI()
        {
            DrawDefaultInspector();
            EditorGUILayout.Space();

            UIController ui = (UIController)target;

            using (new EditorGUI.DisabledScope(!Application.isPlaying))
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    if (GUILayout.Button("Win Panel"))
                    {
                        ui.PreviewEnd(true);
                    }

                    if (GUILayout.Button("Lose Panel"))
                    {
                        ui.PreviewEnd(false);
                    }
                }

                if (GUILayout.Button("Hide Panel"))
                {
                    ui.HideEndPanel();
                }
            }
        }
    }
}