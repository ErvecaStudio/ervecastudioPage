===============================================

	   TALLER DE PATRIMONIO

	      Erveca Studio

===============================================

Instrucciones:

Para introducir vuestras almazuelas en el
proyecto de Unity, primero necesitáis 
digitalizarlas mediante una foto o usando un 
programa de edición de imagen como GIMP.

La imagen tiene que ser cuadrada y en formato 
PNG o JPEG/JPG

1. Para abrir el proyecto instalad la versión 
   6000.3.25f1 de Unity

2. Arrastrad la imagen a la carpeta "Assets".

3. Abrid la carpeta "Scenes" y haced doble clic
   en 2D.

4. En el panel de la izquierda, buscad "Canvas"
   clicad sobre el y buscad "Image".

5. En el panel de la derecha llamado inspector,
   clicad sobre el círculo de "Source Image" y
   buscad vuestra imagen. 
   Si no se ve bien clicad sobre el círculo de
   "Material" y buscad la opción "None".

6. Para verla en 3D. Volved a buscar la carpeta
   "Scenes" y doble clic en 3D.

7. Esperad hasta que en el panel "Game" se deje
   de ver en azul.

8. Buscad la carpeta "Materials", dentro 
   "Almazuela" y dentro clicad sobre la esfera
   "AlmazuelaWind02_2x2".

9. En el panel de la derecha llamado 
   "Inspector", buscad la región llamada 
   "Surface Inputs" y dentro la imagen de la
   almazuela de cuadros. Clicad sobre ella y
   buscad vuestra imagen.

Con esto podréis ver vuestra almazuela en el 
entorno de un videojuego 2D y 3D. 

Si surge alguna duda podéis poneros en 
contacto con nosotros por nuestros canales:

https://linktr.ee/erveca

Todos los elementos del proyecto pueden ser 
usados en vuestros proyectos personales con
una mención a Erveca Studio en los créditos.


